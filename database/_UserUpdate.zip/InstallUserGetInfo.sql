USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[InstallUserGetInfo]    Script Date: 02/22/2015 21:23:01 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[InstallUserGetInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[InstallUserGetInfo]
GO

USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[InstallUserGetInfo]    Script Date: 02/22/2015 21:23:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[InstallUserGetInfo]

	@UserSN BIGINT = NULL
,	@UserSN_Object BIGINT

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT
		@UserSN = UserSN
	,	@UserSN_Object = UserSN_Object
	FROM
		InstallUsers
	WHERE
		UserSN = @UserSN AND UserSN_Object = @UserSN_Object
END

GO


