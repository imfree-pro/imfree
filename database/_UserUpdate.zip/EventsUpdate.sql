USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[EventUpdate]    Script Date: 02/22/2015 21:23:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EventUpdate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[EventUpdate]
GO

USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[EventUpdate]    Script Date: 02/22/2015 21:23:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[EventUpdate]
	@EventSN BIGINT = NULL

,	@Catogory TINYINT = NULL
,	@CatogoryName NVARCHAR(20) = NULL
,	@CallCount INT = NULL
,	@PhoneHash TEXT = NULL
,	@IsDelete TINYINT = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	UPDATE Events
	SET	
		Catogory = ISNULL(Catogory, @Catogory)
	,	CatogoryName = ISNULL(CatogoryName, @CatogoryName)
	,	CallCount = ISNULL(CallCount, @CallCount)
	,	PhoneHash = ISNULL(PhoneHash, @PhoneHash)
	,	IsDelete = ISNULL(IsDelete, @IsDelete)
	WHERE
		EventSN = @EventSN
	
END

GO


