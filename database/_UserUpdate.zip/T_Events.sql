USE [IMFREE]
GO

/****** Object:  Table [dbo].[Events]    Script Date: 02/22/2015 11:26:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Events]') AND type in (N'U'))
DROP TABLE [dbo].[Events]
GO

USE [IMFREE]
GO

/****** Object:  Table [dbo].[Events]    Script Date: 02/22/2015 11:26:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Events](
	[EventsN] [bigint] NOT NULL,
	[CreateDate] [datetime] NOT NULL,
	[UpdateDate] [datetime] NOT NULL,
	[Catogory] [tinyint] NOT NULL,
	[CatogoryName] [nvarchar](20) NOT NULL,
	[CallCount] [int] NOT NULL,
	[PhoneHash] [text] NOT NULL,
	[IsDelete] [tinyint] NOT NULL

 CONSTRAINT [PK_Events] PRIMARY KEY CLUSTERED 
(
	[EventsN] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


