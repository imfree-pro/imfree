USE [IMFREE]
GO

/****** Object:  Table [dbo].[InstallUsers]    Script Date: 02/26/2015 00:42:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[InstallUsers]') AND type in (N'U'))
DROP TABLE [dbo].[InstallUsers]
GO

USE [IMFREE]
GO

/****** Object:  Table [dbo].[InstallUsers]    Script Date: 02/26/2015 00:42:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[InstallUsers](
	[UserSN] [bigint] NOT NULL,
	[UserSN_Object] [bigint] NOT NULL,
 CONSTRAINT [PK_InstallUsers] PRIMARY KEY CLUSTERED 
(
	[UserSN] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


