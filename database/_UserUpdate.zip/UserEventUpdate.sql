USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[UserEventUpdate]    Script Date: 02/22/2015 21:23:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserEventUpdate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[UserEventUpdate]
GO

USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[UserEventUpdate]    Script Date: 02/22/2015 21:23:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UserEventUpdate]
	@UserSN BIGINT = NULL
,	@EventSN BIGINT = NULL

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	UPDATE UserEvents
	SET	
		EventSN = ISNULL(EventSN, @EventSN)
	WHERE
		UserSN = @UserSN
	
END

GO


