USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[UserEventGetInfo]    Script Date: 02/22/2015 21:23:01 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserEventGetInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[UserEventGetInfo]
GO

USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[UserEventGetInfo]    Script Date: 02/22/2015 21:23:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UserEventGetInfo]

	@UserSN BIGINT = NULL
,	@EventSN BIGINT = NULL

,	@CreateDate DATETIME = NULL OUTPUT
,	@UpdateDate DATETIME = NULL OUTPUT
,	@Catogory TINYINT = NULL OUTPUT
,	@CatogoryName NVARCHAR(20) = NULL OUTPUT
,	@CallCount INT = NULL OUTPUT
,	@PhoneHash TEXT = NULL OUTPUT

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT
		@CreateDate = B.CreateDate
	,	@UpdateDate = B.UpdateDate
	,	@Catogory = B.Catogory
	,	@CatogoryName = B.CatogoryName
	,	@CallCount = B.CallCount
	,	@PhoneHash = B.PhoneHash
	FROM
		UserEvents A INNER JOIN Events B ON A.EventSN = B.EventSN
	WHERE
		A.UserSN = @UserSN AND B.EventSN = @EventSN AND B.IsDelete = 0
END

GO


