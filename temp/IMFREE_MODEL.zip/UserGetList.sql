USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[UserGetList]    Script Date: 02/22/2015 21:23:17 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserGetList]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[UserGetList]
GO

USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[UserGetList]    Script Date: 02/22/2015 21:23:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UserGetList] 

	@TotalCount	INT OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	-- Insert statements for procedure here
	SELECT @TotalCount = COUNT(*) FROM Users
	
	SELECT
		UserSN
	,	PhoneHash
	,	CreateDate
	,	UpdateDate
	,	PushKey
	,	DeviceID
	FROM
		Users
		
END

GO


