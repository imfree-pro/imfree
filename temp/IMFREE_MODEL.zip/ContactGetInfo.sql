USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[ContactGetInfo]    Script Date: 02/22/2015 21:23:01 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ContactGetInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ContactGetInfo]
GO

USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[ContactGetInfo]    Script Date: 02/22/2015 21:23:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[ContactGetInfo]
	@UsersSN				BIGINT = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT
		PhoneHash
	,	PhoneName
	FROM
		Contacts
	WHERE
		UsersSN = @UsersSN
END

GO


