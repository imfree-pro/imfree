USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[EventCreate]    Script Date: 02/22/2015 21:22:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EventCreate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[EventCreate]
GO

USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[EventCreate]    Script Date: 02/22/2015 21:22:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[EventCreate]

	@Catogory TINYINT
,	@CatogoryName NVARCHAR(20)
,	@PhoneHash TEXT

,	@EventSN BIGINT OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    
    SELECT TOP 1 @EventSN = EventSN FROM Events ORDER BY EventSN DESC
    
    IF @EventSN IS NULL
		BEGIN
			SET @EventSN = 1
		END
    ELSE
		BEGIN
			SET @EventSN = @EventSN + 1
		END

	INSERT INTO Events
	(
		EventSN
	,	CreateDate
	,	UpdateDate
	,	Catogory
	,	CatogoryName
	,	CallCount
	,	PhoneHash
	,	IsDelete
	)
	VALUES
	(
		@EventSN
	,	GETDATE()
	,	GETDATE()
	,	@Catogory
	,	@CatogoryName
	,	0
	,	@PhoneHash
	,	0
	)
	
END

GO


