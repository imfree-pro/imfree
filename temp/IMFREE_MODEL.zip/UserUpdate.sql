USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[UserUpdate]    Script Date: 02/22/2015 21:23:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserUpdate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[UserUpdate]
GO

USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[UserUpdate]    Script Date: 02/22/2015 21:23:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UserUpdate]
	@UserSN				BIGINT = NULL
,	@PhoneHash		VARCHAR(50) = NULL
,	@PushKey		VARCHAR(50) = NULL
,	@DeviceID		VARCHAR(50) = NULL

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	UPDATE Users
	SET	
		PhoneHash = ISNULL(@PhoneHash, PhoneHash)
	,	UpdateDate = GETDATE()
	,	PushKey = ISNULL(@PushKey, PushKey)
	,	DeviceID = ISNULL(@DeviceID, DeviceID)
	WHERE
		UserSN = @UserSN
	
END

GO


