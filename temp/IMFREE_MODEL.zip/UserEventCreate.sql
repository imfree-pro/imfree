USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[UserEventCreate]    Script Date: 02/22/2015 21:22:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserEventCreate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[UserEventCreate]
GO

USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[UserEventCreate]    Script Date: 02/22/2015 21:22:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UserEventCreate]

	@UserSN BIGINT = NULL
,	@Catogory TINYINT = NULL
,	@CatogoryName NVARCHAR(20) = NULL
,	@PhoneHash TEXT = NULL

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    DECLARE @EventSN BIGINT
    
	EXEC EventCreate @Catogory = @Catogory, @CatogoryName = @CatogoryName, @PhoneHash = @PhoneHash, @EventSN = @EventSN OUTPUT
	
	INSERT INTO UserEvents
	(
		UserSN
	,	EventSN
	)
	SELECT
		@UserSN
	,	@EventSN
	
END

GO


