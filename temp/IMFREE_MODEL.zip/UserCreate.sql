USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[UserCreate]    Script Date: 02/22/2015 21:22:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserCreate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[UserCreate]
GO

USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[UserCreate]    Script Date: 02/22/2015 21:22:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UserCreate]

	@PhoneHash		VARCHAR(50) = NULL
,	@PushKey		VARCHAR(50) = NULL
,	@DeviceID		VARCHAR(50) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    
    DECLARE @UserSN BIGINT
    
    SELECT @UserSN = UserSN FROM Users ORDER BY UserSN DESC
    
    IF @UserSN IS NULL
		BEGIN
			SET @UserSN = 1
		END
    ELSE
		BEGIN
			SET @UserSN = @UserSN + 1
		END
    
	INSERT INTO Users
	(
		UserSN
	,	PhoneHash
	,	CreateDate
	,	UpdateDate
	,	PushKey
	,	DeviceID
	)
	SELECT
		@UserSN
	,	@PhoneHash
	,	GETDATE()
	,	GETDATE()
	,	@PushKey
	,	@DeviceID
	
END

GO


