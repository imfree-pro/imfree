USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[UserGetInfo]    Script Date: 02/22/2015 21:23:01 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserGetInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[UserGetInfo]
GO

USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[UserGetInfo]    Script Date: 02/22/2015 21:23:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UserGetInfo]
	@UserSN				BIGINT = NULL

,	@PhoneHash		VARCHAR(50) OUTPUT
,	@CreateDate		DATETIME OUTPUT
,	@UpdateDate		DATETIME OUTPUT
,	@PushKey		VARCHAR(50) OUTPUT
,	@DeviceID		VARCHAR(50) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT
		@PhoneHash	= PhoneHash
	,	@CreateDate	= CreateDate
	,	@UpdateDate	= UpdateDate
	,	@PushKey	= PushKey
	,	@DeviceID	= DeviceID
	FROM
		Users
	WHERE
		UserSN = @UserSN
END

GO


