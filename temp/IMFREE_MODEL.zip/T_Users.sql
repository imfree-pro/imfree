USE [IMFREE]
GO

/****** Object:  Table [dbo].[Users]    Script Date: 02/22/2015 11:26:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Users]') AND type in (N'U'))
DROP TABLE [dbo].[Users]
GO

USE [IMFREE]
GO

/****** Object:  Table [dbo].[Users]    Script Date: 02/22/2015 11:26:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Users](
	[UserSN] [bigint] NOT NULL,
	[PhoneHash] [varchar](50) NOT NULL,
	[DeviceID] [varchar](50) NOT NULL,
	[PushKey] [varchar](50) NOT NULL,
	[CreateDate] [datetime] NOT NULL,
	[UpdateDate] [datetime] NOT NULL
 CONSTRAINT [PK_Users] PRIMARY KEY CLUSTERED 
(
	[UserSN] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

IF EXISTS (SELECT name from sys.indexes WHERE name = N'IX_PhoneHash_DeviceID') 
   DROP INDEX IX_PhoneHash_DeviceID ON Users; 
GO

CREATE UNIQUE NONCLUSTERED INDEX IX_PhoneHash_DeviceID 
   ON Users (PhoneHash ASC, DeviceID ASC); 
GO

SET ANSI_PADDING OFF
GO


