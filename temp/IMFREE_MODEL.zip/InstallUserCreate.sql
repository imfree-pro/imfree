USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[InstallUserCreate]    Script Date: 02/22/2015 21:22:41 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[InstallUserCreate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[InstallUserCreate]
GO

USE [IMFREE]
GO

/****** Object:  StoredProcedure [dbo].[InstallUserCreate]    Script Date: 02/22/2015 21:22:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[InstallUserCreate]

	@UserSN BIGINT = NULL
,	@UserSN_Object BIGINT = NULL

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	
	INSERT INTO InstallUsers
	(
		UserSN
	,	UserSN_Object
	)
	SELECT
		@UserSN
	,	@UserSN_Object
	
END

GO


